function json(statusCode, data, cache = "no-store") {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": cache,
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    },
    body: JSON.stringify(data)
  };
}

function extractOutputText(payload) {
  const parts = [];
  for (const item of payload?.output || []) {
    for (const content of item?.content || []) {
      if (content?.type === "output_text" && typeof content.text === "string") parts.push(content.text);
    }
  }
  return parts.join("\n").trim();
}

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    recognized: { type: "boolean" },
    normalized_input: { type: "string" },
    formula: { type: "string" },
    canonical_name: { type: "string" },
    vietnamese_name: { type: "string" },
    category: { type: "string" },
    oxidation_states: { type: "array", items: { type: "string" } },
    ions_or_components: { type: "array", items: { type: "string" } },
    aliases: { type: "array", items: { type: "string" } },
    naming_rule: { type: "string" },
    explanation: { type: "string" },
    confidence: { type: "string", enum: ["cao", "trung bình", "thấp"] },
    caution: { type: "string" }
  },
  required: [
    "recognized", "normalized_input", "formula", "canonical_name", "vietnamese_name",
    "category", "oxidation_states", "ions_or_components", "aliases", "naming_rule",
    "explanation", "confidence", "caution"
  ]
};

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return json(204, {});
  if (event.httpMethod !== "POST") return json(405, { error: "METHOD_NOT_ALLOWED" });

  let body = {};
  try { body = JSON.parse(event.body || "{}"); } catch { return json(400, { error: "INVALID_JSON" }); }
  const query = String(body?.query || "").trim();
  if (!query || query.length > 160) return json(400, { error: "INVALID_QUERY", message: "Query must be 1-160 characters." });

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json(503, { error: "OPENAI_API_KEY_MISSING", message: "Configure OPENAI_API_KEY in Netlify Environment Variables." });

  const model = String(process.env.OPENAI_MODEL || "gpt-5-mini").trim();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);

  const instructions = `Bạn là bộ máy tra cứu DANH PHÁP HÓA VÔ CƠ cho giáo viên và học sinh THPT Việt Nam theo GDPT 2018, ưu tiên quy tắc IUPAC hiện hành và cách dùng trong SGK Kết nối tri thức.\n\nNhiệm vụ: nhận MỘT tên chất hoặc công thức và xác định chất. Chỉ cung cấp thông tin nhận diện/danh pháp/cấu tạo thành phần cơ bản; KHÔNG đưa quy trình điều chế, tổng hợp, tinh chế hoặc hướng dẫn thí nghiệm.\n\nQuy tắc chất lượng:\n- Không đoán bừa. Nếu đầu vào mơ hồ, không tồn tại hợp lý, hoặc không đủ dữ kiện để xác định duy nhất, recognized=false và confidence=thấp; giải thích ngắn gọn điểm mơ hồ.\n- Nếu là hợp chất có kim loại nhiều số oxi hóa, ghi số oxi hóa bằng số La Mã trong tên tiếng Anh khi phù hợp, ví dụ iron(III) chloride.\n- Giữ công thức hóa học đúng chỉ số, điện tích và dấu chấm ngậm nước khi có.\n- category nên ngắn gọn, ví dụ: Oxide, Acid, Base, Hydroxide lưỡng tính, Muối, Muối acid, Muối kép, Hợp chất ngậm nước, Ion, Phức chất, Hydride, Peroxide, Superoxide, Khoáng vật/quặng, Nguyên tố.\n- oxidation_states: ghi dạng "Fe: +3", "O: -2"; chỉ nêu các số oxi hóa có ý nghĩa để giải thích tên.\n- ions_or_components: ví dụ "Fe³⁺", "SO₄²⁻", hoặc ligand/nguyên tử trung tâm với phức chất.\n- aliases chỉ đưa tên thường/biến thể thực sự được dùng; không tự sáng tạo.\n- vietnamese_name là tên Việt Nam/diễn giải phù hợp nếu có; nếu không có thì để chuỗi rỗng.\n- caution luôn nhắc rằng kết quả ngoài kho kiểm duyệt cần đối chiếu nguồn IUPAC/SGK trước khi dùng làm đáp án chính thức.`;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        instructions,
        input: `Tra cứu chất sau: ${query}`,
        store: false,
        text: {
          format: {
            type: "json_schema",
            name: "inorganic_compound_lookup",
            description: "Structured inorganic nomenclature lookup result",
            strict: true,
            schema
          }
        }
      })
    });

    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      const providerMessage = payload?.error?.message || `OpenAI HTTP ${response.status}`;
      return json(502, { error: "UPSTREAM_ERROR", message: providerMessage });
    }

    const outputText = extractOutputText(payload);
    if (!outputText) return json(502, { error: "EMPTY_MODEL_OUTPUT", message: "AI service returned no usable result." });

    let result;
    try { result = JSON.parse(outputText); }
    catch { return json(502, { error: "INVALID_MODEL_JSON", message: "AI service returned malformed structured data." }); }

    return json(200, { ...result, query, source: "AI-assisted nomenclature lookup" }, "private, max-age=3600");
  } catch (error) {
    const timedOut = error?.name === "AbortError";
    return json(504, { error: timedOut ? "LOOKUP_TIMEOUT" : "LOOKUP_ERROR", message: timedOut ? "Tra cứu quá thời gian cho phép." : "Không thể kết nối dịch vụ tra cứu." });
  } finally {
    clearTimeout(timer);
  }
};
