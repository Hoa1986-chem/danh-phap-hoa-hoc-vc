function audioResponse(statusCode, body, contentType = 'audio/mpeg') {
  return {
    statusCode,
    isBase64Encoded: statusCode === 200,
    headers: {
      'Content-Type': contentType,
      'Cache-Control': statusCode === 200 ? 'public, max-age=2592000, immutable' : 'no-store',
      'Access-Control-Allow-Origin': '*',
      'X-Content-Type-Options': 'nosniff'
    },
    body
  };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, OPTIONS' }, body: '' };
  }
  if (event.httpMethod !== 'GET') return audioResponse(405, 'METHOD_NOT_ALLOWED', 'text/plain; charset=utf-8');

  const term = String(event.queryStringParameters?.term || '').trim();
  const accent = String(event.queryStringParameters?.accent || 'US').toUpperCase() === 'UK' ? 'UK' : 'US';
  if (!term || term.length > 180 || /[<>]/.test(term)) return audioResponse(400, 'INVALID_TERM', 'text/plain; charset=utf-8');

  const tl = accent === 'UK' ? 'en-GB' : 'en-US';
  const url = new URL('https://translate.google.com/translate_tts');
  url.searchParams.set('ie', 'UTF-8');
  url.searchParams.set('client', 'tw-ob');
  url.searchParams.set('tl', tl);
  url.searchParams.set('q', term);
  url.searchParams.set('ttsspeed', '1');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept': 'audio/mpeg,audio/*;q=0.9,*/*;q=0.5',
        'User-Agent': 'Mozilla/5.0 Chemistry-Nomenclature-App'
      }
    });
    if (!response.ok) return audioResponse(502, 'TTS_UPSTREAM_FAILED', 'text/plain; charset=utf-8');
    const bytes = Buffer.from(await response.arrayBuffer());
    if (!bytes.length) return audioResponse(502, 'EMPTY_TTS_AUDIO', 'text/plain; charset=utf-8');
    return audioResponse(200, bytes.toString('base64'), response.headers.get('content-type') || 'audio/mpeg');
  } catch (error) {
    return audioResponse(502, 'TTS_UNAVAILABLE', 'text/plain; charset=utf-8');
  } finally {
    clearTimeout(timer);
  }
};
