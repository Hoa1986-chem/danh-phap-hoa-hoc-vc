const PRONUNCIATION_API = 'https://api.freedictionary.dev/api/v1/pronunciation/en/';
const DICTIONARY_API = 'https://api.dictionaryapi.dev/api/v2/entries/en/';

function json(statusCode, data, cache = 'public, max-age=86400') {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': cache,
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify(data)
  };
}

function cleanAudioUrl(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (raw.startsWith('//')) return `https:${raw}`;
  if (/^https:\/\//i.test(raw)) return raw;
  return '';
}

function accentFromUrl(url = '') {
  const u = String(url || '').toLowerCase();
  if (/\/uk_pron\/|[_/-](?:uk|gb)[_/-]/.test(u)) return 'UK';
  if (/\/us_pron\/|[_/-]us[_/-]/.test(u)) return 'US';
  return '';
}

async function fetchJson(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Hoa-Hoang-Chemistry-Pronunciation/1.0'
      }
    });
    if (!res.ok) return null;
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function lookupFreeDictionary(term) {
  try {
    const data = await fetchJson(`${PRONUNCIATION_API}${encodeURIComponent(term)}`);
    if (!data) return null;
    const phonetics = Array.isArray(data?.phonetics)
      ? data.phonetics
      : (Array.isArray(data) ? data.flatMap((item) => item?.phonetics || []) : []);
    let audioUS = '';
    let audioUK = '';
    for (const item of phonetics) {
      const audio = cleanAudioUrl(item?.audio);
      if (!audio) continue;
      const type = String(item?.type || '').toLowerCase();
      if (!audioUS && type === 'us') audioUS = audio;
      if (!audioUK && (type === 'uk' || type === 'gb')) audioUK = audio;
      const inferred = accentFromUrl(audio);
      if (!audioUS && inferred === 'US') audioUS = audio;
      if (!audioUK && inferred === 'UK') audioUK = audio;
    }
    if (!audioUS && !audioUK) return null;
    return { audioUS, audioUK, provider: 'Dictionary audio · FreeDictionary' };
  } catch {
    return null;
  }
}

async function lookupDictionaryApi(term) {
  try {
    const data = await fetchJson(`${DICTIONARY_API}${encodeURIComponent(term)}`);
    const entries = Array.isArray(data) ? data : [];
    const phonetics = entries.flatMap((entry) => entry?.phonetics || []);
    let audioUS = '';
    let audioUK = '';
    const unknown = [];
    for (const item of phonetics) {
      const audio = cleanAudioUrl(item?.audio);
      if (!audio) continue;
      const inferred = accentFromUrl(audio);
      if (!audioUS && inferred === 'US') audioUS = audio;
      else if (!audioUK && inferred === 'UK') audioUK = audio;
      else unknown.push(audio);
    }
    // Nếu nguồn chỉ cung cấp một bản không gắn nhãn, dùng nó cho giọng đang thiếu;
    // app vẫn có TTS cục bộ làm fallback nếu upstream không phát được.
    if (!audioUS && unknown.length) audioUS = unknown[0];
    if (!audioUK && unknown.length > 1) audioUK = unknown[1];
    if (!audioUS && !audioUK) return null;
    return { audioUS, audioUK, provider: 'Dictionary audio · Free Dictionary API' };
  } catch {
    return null;
  }
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, OPTIONS' }, body: '' };
  }
  if (event.httpMethod !== 'GET') return json(405, { error: 'METHOD_NOT_ALLOWED' }, 'no-store');

  const term = String(event.queryStringParameters?.term || '').trim().toLowerCase();
  if (!term || term.length > 42 || !/^[a-z]+(?:['-][a-z]+)*$/i.test(term)) {
    return json(400, { error: 'INVALID_TERM' }, 'no-store');
  }

  const primary = await lookupFreeDictionary(term);
  const result = primary || await lookupDictionaryApi(term);
  if (!result) {
    return json(404, { term, error: 'DICTIONARY_AUDIO_NOT_FOUND', isTTSFallback: true }, 'public, max-age=3600');
  }

  return json(200, {
    term,
    ipaUS: '',
    ipaUK: '',
    audioUS: result.audioUS || '',
    audioUK: result.audioUK || '',
    provider: result.provider,
    isTTSFallback: false
  });
};
